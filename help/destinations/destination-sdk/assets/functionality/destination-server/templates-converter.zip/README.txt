This tool is designed add support for External Segments in existing Pebble templates.

The main prerequisite for this tool is JRE 11 (it was tested on Openjdk 11.0.2)

To open this tool with UI support, you need to run this command:

java --module-path="./javafx-sdk-17.0.7/lib" --add-modules=javafx.controls,javafx.fxml -jar templates-converter-ui.jar

If you want to run this tool in CLI mode, here is an example (note that we pass the template as a parameter inside double quotes):

java -jar templates-converter-cli.jar "{\"elements\":[{% for profile in input.profiles %}{\"action\": \"{% for entry in profile.segmentMembership.ups %}{% if loop.first %}{% if entry.value.status == \"exited\" %}REMOVE{%else%}ADD{% endif %}{% endif %}{% endfor %}\",\"userIds\":[{% for hashed_email in profile.identityMap.email_lc_sha256 %}{\"idType\": \"SHA256_EMAIL\",\"idValue\": \"{{ hashed_email.id }}\"}{% if not loop.last %},{% endif %}{% endfor %}{% if profile.identityMap.email_lc_sha256 is not empty and (profile.identityMap.idfa is not empty or profile.identityMap.gaid is not empty) %},{% endif %}{% for idfa in profile.identityMap.idfa %}{\"idType\": \"APPLE_IDFA\",\"idValue\": \"{{ idfa.id }}\"}{% if not loop.last %},{% endif %}{% endfor %}{% if profile.identityMap.idfa is not empty and profile.identityMap.gaid is not empty %},{% endif %}{% for gaid in profile.identityMap.gaid %}{\"idType\": \"GOOGLE_AID\",\"idValue\": \"{{ gaid.id }}\"}{% if not loop.last %},{% endif %}{% endfor %}]}{% if not loop.last %},{% endif %}{% endfor %}]}"

The output is this one:

[main] INFO io.pebbletemplates.pebble.Main - Output:

[main] INFO io.pebbletemplates.pebble.Main - {\"elements\":[{% for profile in input.profiles %}{\"action\": \"{% for namespace in profile.segmentMembership %}{% for entry in profile.segmentMembership[namespace.key] %}{% if loop.first %}{% if entry.value.status==\"exited\" %}REMOVE{% else %}ADD{% endif %}{% endif %}{% endfor %}{% if not loop.last %},{% endif %}{% endfor %}\",\"userIds\":[{% for hashed_email in profile.identityMap.email_lc_sha256 %}{\"idType\": \"SHA256_EMAIL\",\"idValue\": \"{{hashed_email.id}}\"}{% if not loop.last %},{% endif %}{% endfor %}{% if profile.identityMap.email_lc_sha256 is not empty and (profile.identityMap.idfa is not empty or profile.identityMap.gaid is not empty) %},{% endif %}{% for idfa in profile.identityMap.idfa %}{\"idType\": \"APPLE_IDFA\",\"idValue\": \"{{idfa.id}}\"}{% if not loop.last %},{% endif %}{% endfor %}{% if profile.identityMap.idfa is not empty and profile.identityMap.gaid is not empty %},{% endif %}{% for gaid in profile.identityMap.gaid %}{\"idType\": \"GOOGLE_AID\",\"idValue\": \"{{gaid.id}}\"}{% if not loop.last %},{% endif %}{% endfor %}]}{% if not loop.last %},{% endif %}{% endfor %}]}

Disclaimer: please test your template after you convert it with this tool, and make sure it renders correctly on multiple inputs.